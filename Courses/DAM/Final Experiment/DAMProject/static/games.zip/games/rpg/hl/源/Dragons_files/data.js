var gamedata = {
	imageFiles : [ 
		"library/titlescreen.png", 
		"library/gameback1.gif", 
		"library/gameback2.gif", 
		"library/gameback3.gif", 
		"library/monstersheet.gif", 
		"library/bonussheet.gif", 
		"library/background0.gif", 
		"library/bombs.gif", 
		"library/playpause.gif", 
		"library/dragon.gif", 
		"library/volumecontrols.gif",
		"library/splash.png",
		"library/itemsheet.gif"
	],
	audioFiles : [ 
	]
};
